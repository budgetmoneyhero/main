<?php
namespace App\Controllers;

class HealthController {
    public function index() {
        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'time' => date('c')]);
    }
}
