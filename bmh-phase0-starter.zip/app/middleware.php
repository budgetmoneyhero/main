<?php
function requireAuth(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: /log-in'); exit;
    }
}
