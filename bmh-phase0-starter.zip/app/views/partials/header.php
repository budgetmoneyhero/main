<header class="site-header">
  <div class="container">
    <div class="nav-left">Budget Money Hero</div>
    <nav class="nav-right">
      <a href="/log-in" class="btn-link">Log In</a>
      <a href="/sign-up" class="btn-primary">Sign Up</a>
    </nav>
  </div>
</header>
<main class="container">
