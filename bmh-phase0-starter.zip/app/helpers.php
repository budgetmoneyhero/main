<?php
function view(string $template, array $data = []): void {
    extract($data);
    $root = dirname(__DIR__);
    include $root . '/app/views/partials/head.php';
    include $root . '/app/views/partials/header.php';
    include $root . '/app/views/' . $template . '.php';
    include $root . '/app/views/partials/footer.php';
}

function breadcrumb(array $items): void {
    include dirname(__DIR__) . '/app/views/partials/breadcrumbs.php';
}

function h(string $str): string { return htmlspecialchars($str, ENT_QUOTES, 'UTF-8'); }
