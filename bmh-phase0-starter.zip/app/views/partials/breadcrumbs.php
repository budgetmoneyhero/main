<?php /** @var array $items = [['label'=>'Home','href'=>'/'], ['label'=>'About']] */ ?>
<nav class="breadcrumbs">
  <?php foreach ($items as $i => $item): ?>
    <?php if (!empty($item['href']) && $i < count($items)-1): ?>
      <a href="<?= h($item['href']) ?>"><?= h($item['label']) ?></a> <span>›</span>
    <?php else: ?>
      <span class="current"><?= h($item['label']) ?></span>
    <?php endif; ?>
  <?php endforeach; ?>
</nav>
