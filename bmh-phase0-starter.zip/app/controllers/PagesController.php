<?php
namespace App\Controllers;

class PagesController {
    public function home()      { view('pages/home'); }
    public function about()     { view('pages/about'); }
    public function faq()       { view('pages/faq'); }
    public function pricing()   { view('pages/pricing'); }
    public function contact()   { view('pages/contact'); }
    public function privacy()   { view('pages/privacy'); }
    public function terms()     { view('pages/terms'); }
    public function cookies()   { view('pages/cookies'); }
    public function refund()    { view('pages/refund'); }
    public function disclaimer(){ view('pages/disclaimer'); }

    public function login()     { view('auth/login'); }
    public function signup()    { view('auth/signup'); }
}
