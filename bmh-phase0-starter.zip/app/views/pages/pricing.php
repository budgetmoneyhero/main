<?php breadcrumb([['label'=>'Home','href'=>'/'],['label'=>'Pricing']]); ?>
<h1>Pricing</h1>
<p>Content coming in Phase 1.</p>
