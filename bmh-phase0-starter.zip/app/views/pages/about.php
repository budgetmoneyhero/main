<?php breadcrumb([['label'=>'Home','href'=>'/'],['label'=>'About']]); ?>
<h1>About</h1>
<p>Content coming in Phase 1.</p>
