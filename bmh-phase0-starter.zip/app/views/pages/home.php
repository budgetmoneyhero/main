<?php breadcrumb([['label'=>'Home']]); ?>
<section class="hero">
  <h1>Be the Hero of Your Finances</h1>
  <p>$19.99/month after FREE 7-Day Trial.</p>
  <div class="cta-group">
    <a class="btn-primary" href="/sign-up">Start FREE 7-Day Trial</a>
    <a class="btn-secondary" href="/pricing">Learn More</a>
  </div>
</section>
<section><h2>Features</h2><p>Short, simple features overview…</p></section>
<section><h2>Pricing</h2><p>One simple plan — $19.99/mo.</p></section>
<section><h2>Security</h2><p>Stripe Checkout + best practices.</p></section>
<section><h2>Export</h2><p>Export budgets to Excel.</p></section>
<section class="cta-bottom">
  <a class="btn-primary" href="/sign-up">Start FREE 7-Day Trial</a>
</section>
