<?php
namespace App\Services;
/** Phase 4: wrap Stripe SDK calls here */
class StripeClient {}
