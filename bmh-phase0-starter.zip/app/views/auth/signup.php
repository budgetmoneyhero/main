<?php breadcrumb([['label'=>'Home','href'=>'/'],['label'=>'Sign Up']]); ?>
<h1>Sign Up</h1>
<p>Sign up form + Stripe checkout link (Phase 4).</p>
