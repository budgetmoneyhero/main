<?php breadcrumb([['label'=>'Home','href'=>'/'],['label'=>'FAQ']]); ?>
<h1>FAQ</h1>
<p>Content coming in Phase 1.</p>
