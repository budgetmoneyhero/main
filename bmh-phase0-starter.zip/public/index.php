<?php
declare(strict_types=1);

use App\Router;

require __DIR__ . '/../vendor/autoload.php';

$root = dirname(__DIR__);

// Load env
$dotenv = Dotenv\Dotenv::createImmutable($root);
$dotenv->safeLoad();

// Sessions
session_name($_ENV['SESSION_NAME'] ?? 'BMHSESSID');
session_start();

// Router
$router = new Router();

$router->get('/', [App\Controllers\PagesController::class, 'home']);
$router->get('/about', [App\Controllers\PagesController::class, 'about']);
$router->get('/faq', [App\Controllers\PagesController::class, 'faq']);
$router->get('/pricing', [App\Controllers\PagesController::class, 'pricing']);
$router->get('/contact', [App\Controllers\PagesController::class, 'contact']);
$router->get('/privacy-policy', [App\Controllers\PagesController::class, 'privacy']);
$router->get('/terms-of-use', [App\Controllers\PagesController::class, 'terms']);
$router->get('/cookie-policy', [App\Controllers\PagesController::class, 'cookies']);
$router->get('/refund-policy', [App\Controllers\PagesController::class, 'refund']);
$router->get('/disclaimer', [App\Controllers\PagesController::class, 'disclaimer']);

$router->get('/log-in', [App\Controllers\PagesController::class, 'login']);
// NOTE: Sign-up view is present but the real Stripe flow will be wired in Phase 4.
$router->get('/sign-up', [App\Controllers\PagesController::class, 'signup']);

$router->get('/health', [App\Controllers\HealthController::class, 'index']);

$router->dispatch($_SERVER['REQUEST_METHOD'], parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
