</main>
<footer class="site-footer">
  <div class="container footer-grid">
    <div>
      <h3>Budget Money Hero</h3>
      <p>© <?= date('Y') ?> Budget Money Hero. All rights reserved.</p>
    </div>
    <div>
      <h3>Site</h3>
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/about">About</a></li>
        <li><a href="/faq">FAQ</a></li>
        <li><a href="/pricing">Pricing</a></li>
        <li><a href="/contact">Contact Us</a></li>
      </ul>
    </div>
    <div>
      <h3>Legal</h3>
      <ul>
        <li><a href="/privacy-policy">Privacy Policy</a></li>
        <li><a href="/terms-of-use">Terms of Use</a></li>
        <li><a href="/cookie-policy">Cookie Policy</a></li>
        <li><a href="/refund-policy">Refund Policy</a></li>
        <li><a href="/disclaimer">Disclaimer</a></li>
      </ul>
    </div>
    <div>
      <h3>Social</h3>
      <ul class="social">
        <li><a href="#" aria-label="Facebook">Facebook</a></li>
        <li><a href="#" aria-label="Twitter X">X</a></li>
        <li><a href="#" aria-label="YouTube">YouTube</a></li>
      </ul>
    </div>
  </div>
</footer>
<script src="/assets/js/app.js" defer></script>
</body>
</html>
