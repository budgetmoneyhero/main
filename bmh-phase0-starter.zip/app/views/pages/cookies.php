<?php breadcrumb([['label'=>'Home','href'=>'/'],['label'=>'Cookie Policy']]); ?>
<h1>Cookie Policy</h1>
<p>Content coming in Phase 1.</p>
